# Test tiers

## Test runtime

Run repository checks with Bun **1.4.4**, selected by `packageManager` in the root
`package.json`. The dock checks the executing Bun against that declaration.
`framework/docs/harness-baseline.json` retains the historical acceptance environment
(Bun 1.4.2); it is not the current test-runtime selector. Changing the test runtime
does not promote a new harness/provider support combination.

Use the smallest relevant scope while iterating; broaden it at ticket completion and final integration. Explicit task acceptance requirements take precedence over these defaults. Tests supplement, rather than replace, exercising the changed behavior through its smoke or real-host observation seam.

## Select a tier

| Stage | Run | Completion evidence |
| --- | --- | --- |
| Iteration: implementation, debugging, or expectation changes | Affected test files (`bun test <test-file>`). Run `bun run typecheck` after TypeScript changes, including test/support code. | The affected behavior is observed; record failures before broadening the run. |
| Ticket completion | The owning test partition (`bun test <test-directory>`), plus affected consumers of changed shared APIs/behavior. For harness-facing changes, include the corresponding real-host dock files. Run `bun run typecheck` for TypeScript changes. | Each acceptance criterion has evidence or an explicit verification limit; focused green is not a claim of full-repository green. |
| Final integration: assembled changes or independent acceptance | `bun run typecheck` and `bun run test`, plus any smoke/candidate verification explicitly required by the task. | Record the commands, exit statuses, failures, and the source/environment state to which the results apply. |

For framework-mediated adapter completeness, use the [static integration check](../../framework/docs/integration-check.md); it does not run behavior tests. For an exact harness version's functional evidence, choose scripts from [harness version verification](../../framework/docs/harness-support.md#version-verification). These are separate checks, and neither automatically changes support status.

Read `package.json` for existing script names. Use a direct test-directory command when a partition has no named script. Select consumers from the changed contract/callers, not just the directory being edited. If impact remains uncertain, broaden the scope. Documentation-only changes need link/example checks, not a default full test run.

## Full-repository entrypoint

Use `bun run test` for full-repository regression: the package script owns the repository's test scheduling and isolation policy. Keep `bun test <file-or-directory>` for focused validation; bare `bun test` bypasses the full-suite policy.

For explicitly serial full-repository diagnosis, use `bun run test:serial`. Record why serial execution was needed and label that result as diagnostic rather than a replacement for the canonical full-suite run. Do not add retries or relax deadlines to make a parallel run pass.

## Baseline dependencies in isolated worktrees

The frozen harness baseline records sibling anchor and behavior-oracle checkouts. When a temporary worktree does not share those siblings, set `OMP_BASELINE_RECORD_ROOT` to the original toolkit repository root so the recorded cross-repository paths resolve beside it. This changes only dependency path resolution: the toolkit source, installed harness, own lockfile, deployments and test data still come from the worktree. Absolute recorded paths remain unchanged, and all recorded revision, byte-identity and dependency-lock checks still run. Do not repin the baseline or skip these checks to accommodate a worktree layout.

## Pi acceptance versions

Pi native acceptance and smoke entrypoints use the locally selected CLI (`--pi` where offered, `PI_CLI`, otherwise existing local resolution), not a historical exact-version default. The shared policy rejects versions below the highest passed version for that scope in `framework/docs/pi-acceptance.json`; ordering is strict SemVer, not string ordering. Complete passed scopes update their version and source/environment evidence automatically. Filtered native tests, partial smoke modes, failed or blocked runs do not promote a complete scope. Keep source unchanged during acceptance: a changed source digest refuses publication. See [Pi acceptance scopes and commands](../../framework/docs/harness-support.md#commands-and-acceptance-scopes). These checks do not install a version, change normal startup, or alter OMP's fixed baseline. Historical captures remain fixtures, not a requirement to install their original Pi version.

## Historical compatibility fixtures

`tests/framework/fixtures/pi-history/` preserves the Pi 1.4.0 restart and selected-switch JSONL captures originally committed in `68030a9` under the adapter migration baseline artifacts. The native-consumer compatibility tests read these frozen captures directly; do not replace them with output generated by the current adapter or move required fixtures into temporary `.scratch` materials.

Shutdown dock checks must own and await any pending prompt outcome. Stopping a dock session cancels its outstanding frame waiters; do not leave an unobserved prompt to time out during a later test.

Real-backend workflow fixtures register zones with explicit stable IDs (`{ id, path }`).
Map nodes and Run requests refer to those IDs, not filesystem paths; controlled Herdr
cwd/identity observations continue to use the actual owned directories. Keep manager
and node IDs distinct when their directories differ.

For real-backend persistence failure checks, block the destination record path in the test-owned storage (for example, with a directory), then remove the blocker before explicit recovery. Do not depend on a fixed `.tmp` filename: the paired backend may select unique temporary files for atomic publication.

## Store disposable results

Save run-specific evidence, acceptance results, rehearsal records, and test logs under `.scratch/<feature>/evidence/`, using a separate directory per run. Remove them with the feature's scratch materials after development. Long-lived documentation owns reproducible commands, contracts, support boundaries, and operating instructions; it must remain usable after those records are deleted and must not link to or cite them. Keep required test fixtures with the tests, not in scratch storage.

## Keep runs attributable

For coordinated file writes, seeing the expected published document does not mean the writer has released its lock. Tests that compare settled directory contents must also observe lock cleanup before taking the baseline; do not snapshot transient write resources or compensate by extending deadlines. Observe actual filesystem publication for asynchronous persistence assertions instead of assuming a fixed number of immediate turns is enough for disk I/O; keep the test's existing deadline and release observers on completion or teardown. Apply the same publication boundary to accounting, terminal-round restoration, and runtime-gap assertions so an unfinished write cannot leak into the next case's storage root. With fake timers, publication observers must wait for lock cleanup before advancing into the next Round; bound operator-action waits with a monotonic real clock, not a captured `Date.now` that another test file may already have faked.

Held-response disconnect and heartbeat follow-up cases must first establish a successful registration. Use the shipped request budget for that healthy setup and hold only the unregister or heartbeat answer beyond it; reserve deliberately tight setup budgets for registration-timeout cases. Fail explicitly if setup did not arm the session, rather than treating a failed registration as evidence about follow-up requests or waiting for a disconnect notification that an unconnected session never emits. Keep the existing test deadline. For an already-begun write crossing a close-out deadline, establish the real lock-held update before starting disposal; filesystem setup latency must not stand in for the behavior under that deadline.
1. Complete focused runs and any fault injection; restore injected changes before starting final regression.
2. Run expensive suites sequentially in a shared working tree. Agree on a quiet window with peers for real-host or full-repository runs. Inside one run, the full-repository and dock scripts use bounded isolated Bun workers. Use the corresponding `test:serial` or `test:dock:serial` script to diagnose cross-file interference or when parallel real sessions exceed the machine's budget. This intra-run parallelism does not relax the quiet-window rule for multiple people or agents. Warm changed harness or patch prefixes with `bun run test:dock:serial` once before parallel runs, and treat repeated timing or cleanup failures under load as a signal to reduce or remove intra-run parallelism rather than as automatic product failures.
3. Keep tested source and fixtures unchanged until the run finishes. To continue editing, use an isolated snapshot that includes the changes under test. Treat results from a tree changed mid-run as non-final evidence.
4. When materializing isolated deployments, copy shipped source and configuration, not live `framework/.runtime` owner-access records; those records belong to source-tree sessions and may be atomically replaced during concurrent tests. For installed dependency packages, copy their contents with `cpSync(..., { recursive: true, dereference: true })`: the isolated/global-store layout uses links, and recreating those links can require Windows privileges or leave the deployment dependent on another checkout's layout.
5. Save long-run output to a run-specific log so truncated terminal output does not require another suite run just to recover failures or counts.

Reuse an earlier result only when the relevant source, fixtures, dependencies, and environment are unchanged; cite its scope and source state. Rerun after relevant changes, an unstable observation, or an explicit acceptance requirement—not just to reproduce a summary table.

When a failure matches a previously recorded one, compare the case, error signature, and applicable source/environment before citing it. Keep it visible in the result; investigate new or changed failures rather than classifying them by name alone.
