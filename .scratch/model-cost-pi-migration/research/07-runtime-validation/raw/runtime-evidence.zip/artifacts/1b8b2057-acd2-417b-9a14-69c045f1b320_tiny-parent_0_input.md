# Task for tiny-parent

[prompt redacted]; live Prompt Audit only.
