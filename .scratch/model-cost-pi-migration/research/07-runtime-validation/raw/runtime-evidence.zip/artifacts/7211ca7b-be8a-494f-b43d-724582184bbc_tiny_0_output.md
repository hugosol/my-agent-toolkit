Subagent run failed before producing output.

Error:
Agent 'tiny' ran as a foreground child, which never loads the parent's ambient extensions, and these child tools were unavailable: [].
The `tools` field is a strict allowlist; it does not load extension code.
MCP tools require background children (`async: true`) because only they load ambient extensions.
For extension tools a foreground child can load, add the provider path to `subagentOnlyExtensions` (child-only), `extensions`, or as a path-like entry in `tools`, while keeping each registered tool name in `tools`.

Transcript: E:\Developer\pi-playground\wf07-iso\project\.pi\subagents\artifacts\7211ca7b-be8a-494f-b43d-724582184bbc_tiny_0_transcript.jsonl
Metadata: E:\Developer\pi-playground\wf07-iso\project\.pi\subagents\artifacts\7211ca7b-be8a-494f-b43d-724582184bbc_tiny_0_meta.json