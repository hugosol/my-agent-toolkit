# Task for tiny

[prompt redacted]; live Prompt Audit only.
