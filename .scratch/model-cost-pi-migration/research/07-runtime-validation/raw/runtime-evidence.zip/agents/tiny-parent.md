---
name: tiny-parent
description: Bounded nesting validation parent.
model: deepseek/deepseek-flash
tools: subagent, read
systemPromptMode: replace
thinking: off
maxSubagentDepth: 2
timeoutMs: 45000
---
Follow the supplied task exactly. You are explicitly permitted to call subagent once when requested, selecting tiny and deepseek/deepseek-flash. Never retry, never call other tools. Answer at most 8 words after receiving the result.
