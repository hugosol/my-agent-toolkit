---
name: tiny-wait
description: Bounded cancellation validation child.
model: deepseek/deepseek-flash
tools: wf07_pause
systemPromptMode: replace
thinking: off
timeoutMs: 45000
---
Call wf07_pause exactly once, then reply WAITED only. Do not delegate, retry or use other tools.
