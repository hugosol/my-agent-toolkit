const results = await runs.all([
 { key: "left", agent: "tiny", task: "Reply LEFT only", model: "deepseek/deepseek-flash", context: "fresh", timeoutMs: 30000, acceptance: { level: "none", reason: "tiny concurrent probe" } },
 { key: "right", agent: "tiny", task: "Reply RIGHT only", model: "deepseek/deepseek-flash", context: "fresh", timeoutMs: 30000, acceptance: { level: "none", reason: "tiny concurrent probe" } }
]);
return results.map(r => ({runId:r.runId, ok:r.ok, output:r.output}));
