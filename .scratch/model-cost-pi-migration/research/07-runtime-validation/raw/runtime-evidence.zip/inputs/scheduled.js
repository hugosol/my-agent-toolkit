return await runs.run("scheduled", {agent:"tiny",task:"Reply SCHEDULED only",model:"deepseek/deepseek-flash",context:"fresh",timeoutMs:30000,acceptance:{level:"none",reason:"tiny schedule probe"}});
